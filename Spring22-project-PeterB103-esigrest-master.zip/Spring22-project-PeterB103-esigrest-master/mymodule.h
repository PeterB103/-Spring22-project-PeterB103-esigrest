#ifndef _MY_MODULE_H

void hello(const char *name);

#endif