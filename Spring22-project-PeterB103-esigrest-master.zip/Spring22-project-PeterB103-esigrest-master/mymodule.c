#include "mymodule.h"
#include "printf.h"

void hello(const char *name)
{
    printf("Hello, %s!\n", name);
}

